var searchData=
[
  ['name',['NAME',['../a00008.html#a155e69afba8fdf94f5e02351dac5b836',1,'com::example::srclient::Timeslot.NAME()'],['../a00004.html#ab46a019837380a24d1ab7553c1f87569',1,'com::example::srclient::Profile.name()']]]
];
