var searchData=
[
  ['error_5fmsg_5flength',['ERROR_MSG_LENGTH',['../a00013.html#a0a787a895b2e27f8eeac515a0d8ea3ae',1,'kp.h']]]
];
