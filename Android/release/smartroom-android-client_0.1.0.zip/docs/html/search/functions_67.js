var searchData=
[
  ['generateuuid',['generateUuid',['../a00012.html#a4adef8e4d70ec7b3c6e194e879e3e782',1,'generateUuid(char *uuid):&#160;kp.c'],['../a00013.html#a9cc06ac417ccc3789e30608ab7dcddb7',1,'generateUuid(char *):&#160;kp.c']]],
  ['getfieldid',['getFieldID',['../a00012.html#a2f92998d97a0c91b8de42ddb4a96e563',1,'getFieldID(JNIEnv *env, jclass class, char *fieldName, char *signature):&#160;kp.c'],['../a00013.html#ad15eff5eaa23179b01c195e64cfd531f',1,'getFieldID(JNIEnv *, jclass, char *, char *):&#160;kp.c']]],
  ['getjclassobject',['getJClassObject',['../a00012.html#a568e3c5add09ad5ae54e93f687565507',1,'getJClassObject(JNIEnv *env, char *className):&#160;kp.c'],['../a00013.html#afe7de9730d5e5935f7225b9b1034e8e9',1,'getJClassObject(JNIEnv *, char *):&#160;kp.c']]],
  ['getservicesinfo',['getServicesInfo',['../a00003.html#aabfa7235e86b2c57ce86ba91b1a71976',1,'com::example::srclient::KP']]]
];
