var searchData=
[
  ['language',['language',['../a00004.html#a143cac70a14e91c51b88b6a052549132',1,'com::example::srclient::Profile']]],
  ['layoutisactive',['layoutIsActive',['../a00005.html#a966f7857dcc9fa4561a1e833ee84d421',1,'com::example::srclient::Projector']]],
  ['leftarrowbtn',['leftArrowBtn',['../a00005.html#ae5b42d133b1934e1247de724dcec8ad7',1,'com::example::srclient::Projector']]],
  ['linearlayout',['linearLayout',['../a00005.html#a0efe3bb875b54dec3e465632cd71b7db',1,'com::example::srclient::Projector']]]
];
