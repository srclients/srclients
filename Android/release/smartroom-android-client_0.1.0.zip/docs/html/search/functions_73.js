var searchData=
[
  ['searchperson',['searchPerson',['../a00012.html#a011e83f67ec39ef7d5281eda803620c1',1,'searchPerson(individual_t *person, char *userName, char *password):&#160;kp.c'],['../a00013.html#abd9112b0cbc034a34a20a376a96ec148',1,'searchPerson(individual_t *, char *, char *):&#160;kp.c']]],
  ['servicesmenu',['ServicesMenu',['../a00006.html#a2d2e9e1f474c4bbecc71f11bc76a1e4e',1,'com::example::srclient::ServicesMenu']]],
  ['servicesmenuitem',['ServicesMenuItem',['../a00007.html#a64376357eb49337d963c6984f708b998',1,'com::example::srclient::ServicesMenuItem.ServicesMenuItem()'],['../a00007.html#a4e7cc95901f1e67cee6cf5c192718918',1,'com::example::srclient::ServicesMenuItem.ServicesMenuItem(String name, String description)']]],
  ['setimagelink',['setImageLink',['../a00005.html#a4782c20beacee46ec1db18f2110691c8',1,'com::example::srclient::Projector']]],
  ['setpersonuuid',['setPersonUuid',['../a00008.html#aa2ce65d543ce92ab084cffafa8a433d6',1,'com::example::srclient::Timeslot']]],
  ['setviewvalue',['setViewValue',['../a00002.html#ae9a9c511e66a7eee60fe0eeff7220629',1,'com::example::srclient::AgendaViewBinder']]],
  ['startconference',['startConference',['../a00003.html#acf36a37e3f820f1525285afc0147a282',1,'com::example::srclient::KP']]]
];
