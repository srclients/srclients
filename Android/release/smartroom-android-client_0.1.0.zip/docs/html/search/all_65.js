var searchData=
[
  ['editname',['editName',['../a00003.html#aaeb2ddf10ee4a0353bbec568b336abc8',1,'com::example::srclient::KP']]],
  ['editpassword',['editPassword',['../a00003.html#a631343ab1b2296b916faca3055aa1dba',1,'com::example::srclient::KP']]],
  ['error_5fmsg_5flength',['ERROR_MSG_LENGTH',['../a00013.html#a0a787a895b2e27f8eeac515a0d8ea3ae',1,'kp.h']]]
];
