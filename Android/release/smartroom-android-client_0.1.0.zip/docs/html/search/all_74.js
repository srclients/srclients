var searchData=
[
  ['thisobject',['thisObject',['../a00005.html#aa57fa19e901c897164916c47198e611d',1,'com::example::srclient::Projector']]],
  ['timeslot',['Timeslot',['../a00008.html#ade3d4d1671bfc32e7ed8130fb4f5cbbb',1,'com::example::srclient::Timeslot.Timeslot()'],['../a00008.html#aa05c77ba9c77f6759c412dba7c1d7cc5',1,'com::example::srclient::Timeslot.Timeslot(String name, String duration, String title, String img)'],['../a00008.html#ab1d62a769eb0bca259d553c6f3844e92',1,'com::example::srclient::Timeslot.Timeslot(String name, String duration, String title, Drawable img)'],['../a00008.html#aa014d54da017e6f0962577b27fadc381',1,'com::example::srclient::Timeslot.Timeslot(Timeslot item)']]],
  ['timeslot',['Timeslot',['../a00008.html',1,'com::example::srclient']]],
  ['timeslot_2ejava',['Timeslot.java',['../a00021.html',1,'']]],
  ['timeslotlist',['timeslotList',['../a00003.html#aab1e807f71446f708c78e382d4b42c33',1,'com::example::srclient::KP']]],
  ['title',['TITLE',['../a00008.html#a745cd6e747ccc3bcab9899085c9052ee',1,'com::example::srclient::Timeslot']]]
];
