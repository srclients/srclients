var searchData=
[
  ['activateperson',['activatePerson',['../a00012.html#a2e4cc616006be5036d699bb8d1a158e2',1,'activatePerson(individual_t *profile):&#160;kp.c'],['../a00013.html#ace8115930d4e5942cb0319b72d39ad36',1,'activatePerson(individual_t *):&#160;kp.c']]],
  ['addtimeslotitemtolist',['addTimeslotItemToList',['../a00001.html#ae3c3d09f01ce1220af15eb55fa3f96db',1,'com::example::srclient::Agenda']]],
  ['addtimeslottojavalist',['addTimeslotToJavaList',['../a00012.html#ad4cb23cb3788db0faff017e1fa22215c',1,'addTimeslotToJavaList(JNIEnv *env, individual_t *timeslot, jobject obj):&#160;kp.c'],['../a00013.html#a950982d4283ea7f450c29f7f15ccd838',1,'addTimeslotToJavaList(JNIEnv *, individual_t *, jobject):&#160;kp.c']]],
  ['agenda',['Agenda',['../a00001.html#ab12cb31f24f4e2c8d657deede669d9fa',1,'com::example::srclient::Agenda']]],
  ['agendanotifhandler',['agendaNotifHandler',['../a00012.html#afc2964e0aec31c5e03fbd875914efe8f',1,'kp.c']]],
  ['agendaviewbinder',['AgendaViewBinder',['../a00002.html#a054a6fd6b9c7c3935abd9d184d1f7df2',1,'com::example::srclient::AgendaViewBinder']]]
];
