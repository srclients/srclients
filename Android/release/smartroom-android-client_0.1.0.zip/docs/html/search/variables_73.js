var searchData=
[
  ['service_5fdescr',['SERVICE_DESCR',['../a00007.html#acad70bd523b18cf28f6b7514ab816ec6',1,'com::example::srclient::ServicesMenuItem']]],
  ['service_5fname',['SERVICE_NAME',['../a00007.html#a866c8f4ed51930badec57cd2eabe2bab',1,'com::example::srclient::ServicesMenuItem']]],
  ['slidecount',['slideCount',['../a00005.html#a15d91e60db07947329a7eb8d17a38e7b',1,'com::example::srclient::Projector']]],
  ['slideimagedrawable',['slideImageDrawable',['../a00005.html#ad7da366499775b3b22bb8a025c6817f4',1,'com::example::srclient::Projector']]],
  ['slideimagelink',['slideImageLink',['../a00005.html#a78d5121f9df9c019d063d989569ead42',1,'com::example::srclient::Projector']]],
  ['slidenumber',['slideNumber',['../a00005.html#a38f5be0f9a4b61d0f9d794434cc4a259',1,'com::example::srclient::Projector']]],
  ['status',['status',['../a00004.html#a96cf838fc18fede52ed404533153fc47',1,'com::example::srclient::Profile']]]
];
