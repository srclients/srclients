var searchData=
[
  ['kp',['KP',['../a00003.html',1,'com::example::srclient']]],
  ['kp',['KP',['../a00003.html#ae59f39e518b860403b88d7316f0afcb7',1,'com::example::srclient::KP']]],
  ['kp_2ec',['kp.c',['../a00012.html',1,'']]],
  ['kp_2eh',['kp.h',['../a00013.html',1,'']]],
  ['kp_2ejava',['KP.java',['../a00014.html',1,'']]]
];
