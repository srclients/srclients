var searchData=
[
  ['timeslot',['Timeslot',['../a00008.html#ade3d4d1671bfc32e7ed8130fb4f5cbbb',1,'com::example::srclient::Timeslot.Timeslot()'],['../a00008.html#aa05c77ba9c77f6759c412dba7c1d7cc5',1,'com::example::srclient::Timeslot.Timeslot(String name, String duration, String title, String img)'],['../a00008.html#ab1d62a769eb0bca259d553c6f3844e92',1,'com::example::srclient::Timeslot.Timeslot(String name, String duration, String title, Drawable img)'],['../a00008.html#aa014d54da017e6f0962577b27fadc381',1,'com::example::srclient::Timeslot.Timeslot(Timeslot item)']]]
];
