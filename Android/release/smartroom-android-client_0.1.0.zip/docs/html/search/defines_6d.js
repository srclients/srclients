var searchData=
[
  ['max_5fclass_5fname_5flength',['MAX_CLASS_NAME_LENGTH',['../a00013.html#a90e813f27d180a622057fea56dc3682b',1,'kp.h']]]
];
