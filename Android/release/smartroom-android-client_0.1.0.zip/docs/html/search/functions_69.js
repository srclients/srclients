var searchData=
[
  ['initnullproperty',['initNullProperty',['../a00012.html#ad306473c95d3b57e7f5ffc477b8836f4',1,'initNullProperty():&#160;kp.c'],['../a00013.html#ad306473c95d3b57e7f5ffc477b8836f4',1,'initNullProperty():&#160;kp.c']]],
  ['initsubscription',['initSubscription',['../a00003.html#a580e2a4fc7573a7c2122565cf423c0be',1,'com::example::srclient::KP']]]
];
