var searchData=
[
  ['searchperson',['searchPerson',['../a00012.html#a011e83f67ec39ef7d5281eda803620c1',1,'searchPerson(individual_t *person, char *userName, char *password):&#160;kp.c'],['../a00013.html#abd9112b0cbc034a34a20a376a96ec148',1,'searchPerson(individual_t *, char *, char *):&#160;kp.c']]],
  ['service_5fdescr',['SERVICE_DESCR',['../a00007.html#acad70bd523b18cf28f6b7514ab816ec6',1,'com::example::srclient::ServicesMenuItem']]],
  ['service_5fname',['SERVICE_NAME',['../a00007.html#a866c8f4ed51930badec57cd2eabe2bab',1,'com::example::srclient::ServicesMenuItem']]],
  ['servicesmenu',['ServicesMenu',['../a00006.html#a2d2e9e1f474c4bbecc71f11bc76a1e4e',1,'com::example::srclient::ServicesMenu']]],
  ['servicesmenu',['ServicesMenu',['../a00006.html',1,'com::example::srclient']]],
  ['servicesmenu_2ejava',['ServicesMenu.java',['../a00017.html',1,'']]],
  ['servicesmenuitem',['ServicesMenuItem',['../a00007.html',1,'com::example::srclient']]],
  ['servicesmenuitem',['ServicesMenuItem',['../a00007.html#a64376357eb49337d963c6984f708b998',1,'com::example::srclient::ServicesMenuItem.ServicesMenuItem()'],['../a00007.html#a4e7cc95901f1e67cee6cf5c192718918',1,'com::example::srclient::ServicesMenuItem.ServicesMenuItem(String name, String description)']]],
  ['servicesmenuitem_2ejava',['ServicesMenuItem.java',['../a00018.html',1,'']]],
  ['setimagelink',['setImageLink',['../a00005.html#a4782c20beacee46ec1db18f2110691c8',1,'com::example::srclient::Projector']]],
  ['setpersonuuid',['setPersonUuid',['../a00008.html#aa2ce65d543ce92ab084cffafa8a433d6',1,'com::example::srclient::Timeslot']]],
  ['setviewvalue',['setViewValue',['../a00002.html#ae9a9c511e66a7eee60fe0eeff7220629',1,'com::example::srclient::AgendaViewBinder']]],
  ['slidecount',['slideCount',['../a00005.html#a15d91e60db07947329a7eb8d17a38e7b',1,'com::example::srclient::Projector']]],
  ['slideimagedrawable',['slideImageDrawable',['../a00005.html#ad7da366499775b3b22bb8a025c6817f4',1,'com::example::srclient::Projector']]],
  ['slideimagelink',['slideImageLink',['../a00005.html#a78d5121f9df9c019d063d989569ead42',1,'com::example::srclient::Projector']]],
  ['slidenumber',['slideNumber',['../a00005.html#a38f5be0f9a4b61d0f9d794434cc4a259',1,'com::example::srclient::Projector']]],
  ['smartroomontology_2ec',['SmartRoomOntology.c',['../a00019.html',1,'']]],
  ['smartroomontology_2eh',['SmartRoomOntology.h',['../a00020.html',1,'']]],
  ['startconference',['startConference',['../a00003.html#acf36a37e3f820f1525285afc0147a282',1,'com::example::srclient::KP']]],
  ['status',['status',['../a00004.html#a96cf838fc18fede52ed404533153fc47',1,'com::example::srclient::Profile']]]
];
