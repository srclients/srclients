var searchData=
[
  ['register_5fontology',['register_ontology',['../a00019.html#a1286cc0d1ea1501b8991e73066832cfe',1,'register_ontology():&#160;SmartRoomOntology.c'],['../a00020.html#a1286cc0d1ea1501b8991e73066832cfe',1,'register_ontology():&#160;SmartRoomOntology.c']]]
];
