var searchData=
[
  ['absentimg',['absentImg',['../a00001.html#a53fac6c8856030227143b73484a31a63',1,'com::example::srclient::Agenda']]],
  ['activateperson',['activatePerson',['../a00012.html#a2e4cc616006be5036d699bb8d1a158e2',1,'activatePerson(individual_t *profile):&#160;kp.c'],['../a00013.html#ace8115930d4e5942cb0319b72d39ad36',1,'activatePerson(individual_t *):&#160;kp.c']]],
  ['addtimeslotitemtolist',['addTimeslotItemToList',['../a00001.html#ae3c3d09f01ce1220af15eb55fa3f96db',1,'com::example::srclient::Agenda']]],
  ['addtimeslottojavalist',['addTimeslotToJavaList',['../a00012.html#ad4cb23cb3788db0faff017e1fa22215c',1,'addTimeslotToJavaList(JNIEnv *env, individual_t *timeslot, jobject obj):&#160;kp.c'],['../a00013.html#a950982d4283ea7f450c29f7f15ccd838',1,'addTimeslotToJavaList(JNIEnv *, individual_t *, jobject):&#160;kp.c']]],
  ['age',['age',['../a00004.html#a8cef400b71b9094b6748f40651f45cf9',1,'com::example::srclient::Profile']]],
  ['agenda',['Agenda',['../a00001.html#ab12cb31f24f4e2c8d657deede669d9fa',1,'com::example::srclient::Agenda']]],
  ['agenda',['Agenda',['../a00001.html',1,'com::example::srclient']]],
  ['agenda_2ejava',['Agenda.java',['../a00009.html',1,'']]],
  ['agendanotifhandler',['agendaNotifHandler',['../a00012.html#afc2964e0aec31c5e03fbd875914efe8f',1,'kp.c']]],
  ['agendaservicestate',['agendaServiceState',['../a00006.html#acf01191ec9dc467b3ffce4b804d4b664',1,'com::example::srclient::ServicesMenu']]],
  ['agendaviewbinder',['AgendaViewBinder',['../a00002.html#a054a6fd6b9c7c3935abd9d184d1f7df2',1,'com::example::srclient::AgendaViewBinder']]],
  ['agendaviewbinder',['AgendaViewBinder',['../a00002.html',1,'com::example::srclient']]],
  ['agendaviewbinder_2ejava',['AgendaViewBinder.java',['../a00010.html',1,'']]]
];
