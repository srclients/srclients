var searchData=
[
  ['onclick',['onClick',['../a00003.html#a22416d3cb2e2b7823439523d325dbcb6',1,'com::example::srclient::KP.onClick()'],['../a00005.html#ac2007017a0c9b8defef41fdd830be653',1,'com::example::srclient::Projector.onClick()']]],
  ['oncreate',['onCreate',['../a00001.html#a3ed51afaa91694517d367ab23aa229c4',1,'com::example::srclient::Agenda.onCreate()'],['../a00003.html#a2174f7c9232da6f05185c10cbd51c3dd',1,'com::example::srclient::KP.onCreate()'],['../a00004.html#a7f048c19ef542cdf882a49404986b96b',1,'com::example::srclient::Profile.onCreate()'],['../a00005.html#a850c957a5ab528df5bded434f7c685bb',1,'com::example::srclient::Projector.onCreate()'],['../a00006.html#a9a9e05f86c5c3275df45b8cba49a792f',1,'com::example::srclient::ServicesMenu.onCreate()']]],
  ['oncreateoptionsmenu',['onCreateOptionsMenu',['../a00001.html#a8d2d20c9c1d30cf02975c8f9172aee8a',1,'com::example::srclient::Agenda.onCreateOptionsMenu()'],['../a00005.html#a7d017774223515b1eedb35c64ba4b4eb',1,'com::example::srclient::Projector.onCreateOptionsMenu()']]],
  ['onlistitemclick',['onListItemClick',['../a00006.html#a2ce878dad69d512666a6dc6cdd34d7e3',1,'com::example::srclient::ServicesMenu']]],
  ['onoptionsitemselected',['onOptionsItemSelected',['../a00001.html#acf7933bc6cfda04c0ab3343817b131e6',1,'com::example::srclient::Agenda.onOptionsItemSelected()'],['../a00005.html#ad793794467ef9999042f262fdb89bf3f',1,'com::example::srclient::Projector.onOptionsItemSelected()']]],
  ['organization',['organization',['../a00004.html#a213193783eb0bbfec3c12426cb80d5dd',1,'com::example::srclient::Profile']]]
];
