var searchData=
[
  ['loadimage',['loadImage',['../a00001.html#a5d462d0d21bcc66725e642ce1ee688fe',1,'com::example::srclient::Agenda.loadImage()'],['../a00005.html#a8266e5c8a147f745329a2046f4b20e79',1,'com::example::srclient::Projector.loadImage()']]],
  ['loadpersoninfo',['loadPersonInfo',['../a00012.html#ae18d6e73fb0106d173a334c1d20e9168',1,'kp.c']]],
  ['loadpresentation',['loadPresentation',['../a00003.html#a771ce9b6977477214a13bdb962604f9f',1,'com::example::srclient::KP']]],
  ['loadtimeslotlist',['loadTimeslotList',['../a00003.html#adb40489726ce1a0795c64e12110ef0ad',1,'com::example::srclient::KP']]]
];
