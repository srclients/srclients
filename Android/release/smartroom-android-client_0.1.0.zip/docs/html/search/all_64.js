var searchData=
[
  ['disconnectsmartspace',['disconnectSmartSpace',['../a00003.html#a8508bbb4c777780589a0864d032568b5',1,'com::example::srclient::KP']]],
  ['duration',['DURATION',['../a00008.html#ad219a68405fc066fd8849d144dc064b1',1,'com::example::srclient::Timeslot']]]
];
