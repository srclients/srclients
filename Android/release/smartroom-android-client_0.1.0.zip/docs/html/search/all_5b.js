var searchData=
[
  ['_5bstatic_20initializer_5d',['[static initializer]',['../a00003.html#a37712cf59e3ba2f0cbf5014c1105dba2',1,'com::example::srclient::KP']]]
];
