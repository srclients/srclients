var searchData=
[
  ['connectsmartspace',['connectSmartSpace',['../a00003.html#a3ea49f46cf1d9e2fd89c13695b49bd94',1,'com::example::srclient::KP']]]
];
