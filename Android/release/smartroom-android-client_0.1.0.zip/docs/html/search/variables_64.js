var searchData=
[
  ['duration',['DURATION',['../a00008.html#ad219a68405fc066fd8849d144dc064b1',1,'com::example::srclient::Timeslot']]]
];
