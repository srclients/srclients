var searchData=
[
  ['editname',['editName',['../a00003.html#aaeb2ddf10ee4a0353bbec568b336abc8',1,'com::example::srclient::KP']]],
  ['editpassword',['editPassword',['../a00003.html#a631343ab1b2296b916faca3055aa1dba',1,'com::example::srclient::KP']]]
];
