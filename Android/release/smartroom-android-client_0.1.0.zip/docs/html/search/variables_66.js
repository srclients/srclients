var searchData=
[
  ['firsttimeslot',['firstTimeslot',['../a00012.html#a80b1c20c4de62a8e406b43f0aaad0048',1,'kp.c']]]
];
