/*
 * 
 */
package com.example.srclient;

import android.app.Activity;
import android.os.Bundle;

// TODO: Auto-generated Javadoc
/**
 * The Class Profile.
 */
public class Profile extends Activity {

	/** The name. */
	public String name;
	
	/** The status. */
	public String status;
	
	/** The image. */
	public String image;
	
	/** The age. */
	public String age;
	
	/** The mbox. */
	public String mbox;
	
	/** The phone. */
	public String phone;
	
	/** The language. */
	public String language;
	
	/** The interests. */
	public String interests;
	
	/** The organization. */
	public String organization;
	
	/**
	 * Instantiates a new profile.
	 */
	public Profile() {
		
	}
	
	/* (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
	}

}
